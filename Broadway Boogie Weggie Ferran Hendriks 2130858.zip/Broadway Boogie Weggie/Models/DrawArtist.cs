﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace Broadway_Boogie_Weggie.Models
//{
//    public class DrawArtist
//    {
//        public double X { get; set; }
//        public double Y { get; set; }
//        public double Width { get => Gallery.ARTIST_WIDTH; }
//        public double Height { get => Gallery.ARTIST_HEIGHT; }
//        public string Color { get => "black"; }

//        public DrawArtist(Artist artist)
//        {
//            this.X = artist.X + Width;
//            this.Y = artist.Y + Height;
//        }
//    }
//}
