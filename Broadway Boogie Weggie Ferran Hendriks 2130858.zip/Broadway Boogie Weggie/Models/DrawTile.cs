﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace Broadway_Boogie_Weggie.Models
//{
//    public class DrawTile
//    {
//        public double X { get; set; }
//        public double Y { get; set; }
//        public int Weight { get; set; }
//        public double Width { get => Gallery.TILE_WIDTH; }
//        public double Height { get => Gallery.TILE_HEIGHT; }
//        public string Color { get; set; }

//        public DrawTile(double x, double y, int weight, string color)
//        {
//            this.X = x;
//            this.Y = y;
//            this.Weight = weight;
//            this.Color = color;
//        }
//    }
//}
